const QTY_OPTIONS = [1, 2, 3, 4];

export {
  QTY_OPTIONS
}
