const LABELS = {
  PRODUCT_NAME: 'Bed, Bath and Beyond',
  PRICE_UNIT: 'USD',
  ORDER_SUMMARY_HEADING: 'Order Summary',
  PRODUCT: 'Product',
  AMOUNT: 'Amount',
  SHIPPING_CHARGES: 'Shipping Charges',
  TOTAL: 'Total',
  CHECKOUT: 'Checkout',
  QTY: 'Qty',
  REMOVE: 'Remove',
  YOUR_CART: 'Your Cart',
  ORDER_PLACED_SUCCESSFULLY_MSG: 'Order placed successfully!'
}

export default LABELS
